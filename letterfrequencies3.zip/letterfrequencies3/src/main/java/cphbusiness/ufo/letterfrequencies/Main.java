package cphbusiness.ufo.letterfrequencies;

import java.io.*;
import java.sql.Array;
import java.util.*;

import static java.util.stream.Collectors.toMap;

/**
 * Frequency analysis Inspired by
 * https://en.wikipedia.org/wiki/Frequency_analysis
 *
 * @author kasper
 */




public class Main {

    public static void main(String[] args) throws FileNotFoundException, IOException {

        String fileName = "/Users/benja/Documents/Downloads/letterfrequencies/src/main/resources/FoundationSeries.txt";
        //Reader reader = new FileReader(fileName);

        File f = new File(fileName);
        FileInputStream fis = new FileInputStream(f);
        BufferedInputStream reader = new BufferedInputStream(fis);

        List time_list = new ArrayList();
        Map<Integer, Long> freq = new HashMap<>();
        
        for(int i = 0; i < 100; i++) {
            long startTime = System.nanoTime();
            tallyChars(reader, freq);
            long timeElapsed = System.nanoTime() - startTime;
            time_list.add(timeElapsed / 1_000_000  );
        }
        print_tally(freq);
        System.out.println(time_list);
        //System.out.println( "Time elapsed (millisec): " + timeElapsed / 1_000_000 );

    }

    private static void tallyChars(BufferedInputStream reader, Map<Integer, Long> freq) throws IOException {
        int b;
        while ((b = reader.read()) != -1) {
            try {
                freq.put(b, freq.get(b) + 1);
            } catch (NullPointerException np) {
                freq.put(b, 1L);
            };
        }
    }

    private static void print_tally(Map<Integer, Long> freq) {
        int dist = 'a' - 'A';
        Map<Character, Long> upperAndlower = new LinkedHashMap();
        for (Character c = 'A'; c <= 'Z'; c++) {
            upperAndlower.put(c, freq.getOrDefault(c, 0L) + freq.getOrDefault(c + dist, 0L));
        }
        Map<Character, Long> sorted = upperAndlower
                .entrySet()
                .stream()
                .sorted(Collections.reverseOrder(Map.Entry.comparingByValue()))
                .collect(
                        toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e2,
                                LinkedHashMap::new));
        for (Character c : sorted.keySet()) {
            System.out.println("" + c + ": " + sorted.get(c));;
        }
    }
}
