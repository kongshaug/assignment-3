# Letter frequencies
Simple program used to illustrate performance problems. You should be able to optimize this program to run about twice as fast.
